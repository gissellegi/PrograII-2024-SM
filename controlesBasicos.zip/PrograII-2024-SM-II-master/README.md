# PrograII-2024-SM-II
Códigos de la Clase de Programación II - 2024 - Ciclo I - SM 

# PROYETO FINAL DE CATEDRA.
# Requerimientos del proyecto final.
* Equipos de trabajo - 4 Integrantes Maximo 5.
* Base de Datos (Sqlite -> Local, CouchDB, Firebase, Mongo -> Nube)
* WebServices
* Notificaciones PUSH
* Uso de Sensores (Acelerometro, Giroscopio, Luz, GPS, Proximidad, Camara, etc.) 
* Multimedia (Audio, Imagenes, Videos, Graficos)
* Chats de usuarios
* Menus
* Creativad e innovacion.

Ejm. de Proyectos Finales.
* Sistema de votacion electronica (Elecciones presidenciales, alcaldes y diputados, Reinas de belleza, etc.) #IA para analizar los comentarios de los usuarios si son positivos o negativos.
* Sistema de restaurante: acceder al numero de mesa y menu via codigo QR -> Se envia la orden a cocina, cocina o meseros informan cuando se despache... #IA para analizar los comentarios de los usuarios si son positivos o negativos.
